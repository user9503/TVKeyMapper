# ProGuard rules for TV Key Mapper
-keep public class * extends android.app.Activity
-keep public class * extends android.accessibilityservice.AccessibilityService
