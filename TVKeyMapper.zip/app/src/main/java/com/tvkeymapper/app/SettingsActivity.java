package com.tvkeymapper.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private CheckBox cbAltEscHome;
    private CheckBox cbEscBack;
    private CheckBox cbFnPrintScreenshot;
    private CheckBox cbAltF4Close;
    private CheckBox cbShowToast;
    private SeekBar sbComboTimeout;
    private TextView tvTimeoutValue;
    private TextView tvSettingsInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = getSharedPreferences("TVKeyMapperPrefs", MODE_PRIVATE);

        cbAltEscHome = findViewById(R.id.cbAltEscHome);
        cbEscBack = findViewById(R.id.cbEscBack);
        cbFnPrintScreenshot = findViewById(R.id.cbFnPrintScreenshot);
        cbAltF4Close = findViewById(R.id.cbAltF4Close);
        cbShowToast = findViewById(R.id.cbShowToast);
        sbComboTimeout = findViewById(R.id.sbComboTimeout);
        tvTimeoutValue = findViewById(R.id.tvTimeoutValue);
        tvSettingsInfo = findViewById(R.id.tvSettingsInfo);

        loadSettings();
        setupListeners();
    }

    private void loadSettings() {
        cbAltEscHome.setChecked(prefs.getBoolean("alt_esc_home", true));
        cbEscBack.setChecked(prefs.getBoolean("esc_back", true));
        cbFnPrintScreenshot.setChecked(prefs.getBoolean("fn_print_screenshot", true));
        cbAltF4Close.setChecked(prefs.getBoolean("alt_f4_close", true));
        cbShowToast.setChecked(prefs.getBoolean("show_toast", true));

        int timeout = prefs.getInt("combo_timeout", 300);
        sbComboTimeout.setProgress((timeout - 100) / 50);
        tvTimeoutValue.setText(timeout + "ms");
    }

    private void setupListeners() {
        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) -> saveSettings();

        cbAltEscHome.setOnCheckedChangeListener(listener);
        cbEscBack.setOnCheckedChangeListener(listener);
        cbFnPrintScreenshot.setOnCheckedChangeListener(listener);
        cbAltF4Close.setOnCheckedChangeListener(listener);
        cbShowToast.setOnCheckedChangeListener(listener);

        sbComboTimeout.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int timeout = progress * 50 + 100;
                tvTimeoutValue.setText(timeout + "ms");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveSettings();
            }
        });
    }

    private void saveSettings() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("alt_esc_home", cbAltEscHome.isChecked());
        editor.putBoolean("esc_back", cbEscBack.isChecked());
        editor.putBoolean("fn_print_screenshot", cbFnPrintScreenshot.isChecked());
        editor.putBoolean("alt_f4_close", cbAltF4Close.isChecked());
        editor.putBoolean("show_toast", cbShowToast.isChecked());
        editor.putInt("combo_timeout", sbComboTimeout.getProgress() * 50 + 100);
        editor.apply();

        Toast.makeText(this, "Settings Saved!", Toast.LENGTH_SHORT).show();
    }
}
