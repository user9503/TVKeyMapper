package com.tvkeymapper.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;
    private TextView tvInfo;
    private Button btnEnableService;
    private Button btnSettings;
    private Button btnTestKeys;
    private Button btnHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        tvInfo = findViewById(R.id.tvInfo);
        btnEnableService = findViewById(R.id.btnEnableService);
        btnSettings = findViewById(R.id.btnSettings);
        btnTestKeys = findViewById(R.id.btnTestKeys);
        btnHelp = findViewById(R.id.btnHelp);

        btnEnableService.setOnClickListener(v -> openAccessibilitySettings());
        btnSettings.setOnClickListener(v -> openSettings());
        btnTestKeys.setOnClickListener(v -> testKeys());
        btnHelp.setOnClickListener(v -> showHelp());

        // Check if opened from help shortcut
        if (getIntent().getBooleanExtra("show_help", false)) {
            showHelp();
        }

        checkServiceStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkServiceStatus();
    }

    private void checkServiceStatus() {
        boolean isEnabled = isAccessibilityServiceEnabled();
        if (isEnabled) {
            tvStatus.setText("✅ SERVICE ACTIVE");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            btnEnableService.setText("Service Running ✓");
            btnEnableService.setEnabled(false);
            tvInfo.setText("Your keyboard shortcuts are now working!\nTry Alt+Esc for Home, Esc for Back");
        } else {
            tvStatus.setText("❌ SERVICE DISABLED");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            btnEnableService.setText("Enable Accessibility Service");
            btnEnableService.setEnabled(true);
            tvInfo.setText("You MUST enable the accessibility service for keyboard shortcuts to work!");
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am == null) return false;

        List<AccessibilityServiceInfo> enabledServices = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);

        for (AccessibilityServiceInfo service : enabledServices) {
            if (service.getId().contains(getPackageName())) {
                return true;
            }
        }
        return false;
    }

    private void openAccessibilitySettings() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);
        Toast.makeText(this, "Find 'TV Key Mapper' and turn it ON", Toast.LENGTH_LONG).show();
    }

    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    private void testKeys() {
        Toast.makeText(this, 
            "Test these shortcuts now:\n" +
            "Alt+Esc = Home\n" +
            "Esc = Back\n" +
            "Fn+Print = Screenshot\n" +
            "Alt+F4 = Recent Apps", 
            Toast.LENGTH_LONG).show();
    }

    private void showHelp() {
        String help = "TV Key Mapper - Help\n\n" +
                "Default Shortcuts:\n" +
                "• Alt + Esc → Go to Home\n" +
                "• Esc → Go Back\n" +
                "• Fn + Print → Take Screenshot\n" +
                "• Alt + F4 → Open Recent Apps\n" +
                "• Alt + F1 → Show this Help\n\n" +
                "Troubleshooting:\n" +
                "• Make sure Accessibility Service is ON\n" +
                "• Some keyboards send different key codes\n" +
                "• Try pressing modifiers slightly before main key\n" +
                "• Increase combo timeout in Settings if needed";

        Toast.makeText(this, help, Toast.LENGTH_LONG).show();
    }
}
