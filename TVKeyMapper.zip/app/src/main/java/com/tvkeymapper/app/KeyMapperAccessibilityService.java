package com.tvkeymapper.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class KeyMapperAccessibilityService extends AccessibilityService {

    private static final String TAG = "TVKeyMapper";
    private static final String CHANNEL_ID = "tvkeymapper_service";
    private static final int NOTIFICATION_ID = 1;
    private static final String PREFS_NAME = "TVKeyMapperPrefs";

    // Key tracking
    private boolean altPressed = false;
    private boolean fnPressed = false;
    private long lastAltPressTime = 0;
    private long lastFnPressTime = 0;
    private long lastMetaPressTime = 0;
    private boolean metaPressed = false;

    private Handler mainHandler;
    private SharedPreferences prefs;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility Service Connected");

        mainHandler = new Handler(Looper.getMainLooper());
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Configure service
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                    | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    | AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            setServiceInfo(info);
        }

        createNotificationChannel();
        startForegroundService();

        Toast.makeText(this, "TV Key Mapper Active! Keyboard shortcuts enabled.", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Handle window changes if needed
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Service Interrupted");
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        int action = event.getAction();
        int metaState = event.getMetaState();

        Log.d(TAG, "KeyEvent: code=" + keyCode + " action=" + action + " meta=" + metaState);

        int comboTimeout = prefs.getInt("combo_timeout", 300);
        boolean showToast = prefs.getBoolean("show_toast", true);

        // Track modifier keys
        if (keyCode == KeyEvent.KEYCODE_ALT_LEFT || keyCode == KeyEvent.KEYCODE_ALT_RIGHT) {
            altPressed = (action == KeyEvent.ACTION_DOWN);
            if (action == KeyEvent.ACTION_DOWN) lastAltPressTime = System.currentTimeMillis();
        }

        if (keyCode == KeyEvent.KEYCODE_FUNCTION) {
            fnPressed = (action == KeyEvent.ACTION_DOWN);
            if (action == KeyEvent.ACTION_DOWN) lastFnPressTime = System.currentTimeMillis();
        }

        if (keyCode == KeyEvent.KEYCODE_META_LEFT || keyCode == KeyEvent.KEYCODE_META_RIGHT) {
            metaPressed = (action == KeyEvent.ACTION_DOWN);
            if (action == KeyEvent.ACTION_DOWN) lastMetaPressTime = System.currentTimeMillis();
        }

        // Also check meta state from event
        boolean altFromMeta = (metaState & KeyEvent.META_ALT_ON) != 0;
        boolean metaFromState = (metaState & KeyEvent.META_META_ON) != 0;

        // Handle key combinations on KEY_UP
        if (action == KeyEvent.ACTION_UP) {
            long currentTime = System.currentTimeMillis();
            boolean altActive = altPressed || altFromMeta;
            boolean fnActive = fnPressed;
            boolean metaActive = metaPressed || metaFromState;

            // Alt + Esc → Home
            if (keyCode == KeyEvent.KEYCODE_ESCAPE && altActive) {
                if (currentTime - lastAltPressTime < comboTimeout + 200) {
                    if (prefs.getBoolean("alt_esc_home", true)) {
                        performGlobalAction(GLOBAL_ACTION_HOME);
                        if (showToast) showFeedback("🏠 Home");
                        return true;
                    }
                }
            }

            // Meta + Esc → Home (alternative)
            if (keyCode == KeyEvent.KEYCODE_ESCAPE && metaActive) {
                if (currentTime - lastMetaPressTime < comboTimeout + 200) {
                    if (prefs.getBoolean("alt_esc_home", true)) {
                        performGlobalAction(GLOBAL_ACTION_HOME);
                        if (showToast) showFeedback("🏠 Home");
                        return true;
                    }
                }
            }

            // Esc alone → Back
            if (keyCode == KeyEvent.KEYCODE_ESCAPE && !altActive && !metaActive && !fnActive) {
                if (prefs.getBoolean("esc_back", true)) {
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    if (showToast) showFeedback("◀ Back");
                    return true;
                }
            }

            // Fn + Print/SysRq → Screenshot
            if ((keyCode == KeyEvent.KEYCODE_SYSRQ || keyCode == KeyEvent.KEYCODE_PRINT) && fnActive) {
                if (currentTime - lastFnPressTime < comboTimeout + 200) {
                    if (prefs.getBoolean("fn_print_screenshot", true)) {
                        takeScreenshot();
                        if (showToast) showFeedback("📸 Screenshot");
                        return true;
                    }
                }
            }

            // Alt + F4 → Close app (Recent apps)
            if (keyCode == KeyEvent.KEYCODE_F4 && altActive) {
                if (currentTime - lastAltPressTime < comboTimeout + 200) {
                    if (prefs.getBoolean("alt_f4_close", true)) {
                        performGlobalAction(GLOBAL_ACTION_RECENTS);
                        if (showToast) showFeedback("📋 Recent Apps");
                        return true;
                    }
                }
            }

            // Alt + F1 → Show help
            if (keyCode == KeyEvent.KEYCODE_F1 && altActive) {
                if (currentTime - lastAltPressTime < comboTimeout + 200) {
                    showHelpOverlay();
                    return true;
                }
            }

            // Home key direct
            if (keyCode == KeyEvent.KEYCODE_MOVE_HOME || keyCode == KeyEvent.KEYCODE_HOME) {
                performGlobalAction(GLOBAL_ACTION_HOME);
                if (showToast) showFeedback("🏠 Home");
                return true;
            }

            // Media keys
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_NEXT) {
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS) {
                sendMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
                return true;
            }

            // Volume fix for some keyboards
            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                adjustVolume(AudioManager.ADJUST_RAISE);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
                adjustVolume(AudioManager.ADJUST_LOWER);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) {
                adjustVolume(AudioManager.ADJUST_TOGGLE_MUTE);
                return true;
            }
        }

        return super.onKeyEvent(event);
    }

    private void takeScreenshot() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
        } else {
            try {
                String filename = "/sdcard/Pictures/Screenshots/tv_screenshot_" 
                    + System.currentTimeMillis() + ".png";
                Runtime.getRuntime().exec("screencap -p " + filename);
                Toast.makeText(this, "Screenshot saved", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Screenshot failed", e);
                Toast.makeText(this, "Screenshot: Try Power+Volume Down", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendMediaKey(int keyCode) {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            KeyEvent downEvent = new KeyEvent(KeyEvent.ACTION_DOWN, keyCode);
            KeyEvent upEvent = new KeyEvent(KeyEvent.ACTION_UP, keyCode);
            audioManager.dispatchMediaKeyEvent(downEvent);
            audioManager.dispatchMediaKeyEvent(upEvent);
        }
    }

    private void adjustVolume(int direction) {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager != null) {
            audioManager.adjustVolume(direction, AudioManager.FLAG_SHOW_UI);
        }
    }

    private void startForegroundService() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("TV Key Mapper")
                .setContentText("Keyboard shortcuts active - Alt+Esc=Home, Esc=Back")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "TV Key Mapper Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Keeps keyboard shortcut mapping active");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void showFeedback(String message) {
        mainHandler.post(() -> {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        });
    }

    private void showHelpOverlay() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("show_help", true);
        startActivity(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
